import React from 'react'
import { Col, Row } from 'react-bootstrap'
import RestCard from '../components/RestCard'

function Home() {
  return (
    <div><Row>
        <Col className='px-5 py-3' sm={6} md={3} >
        <RestCard/>
        </Col>
        <Col className='px-5 py-3' sm={6} md={3} >
        <RestCard/>
        </Col>
        <Col className='px-5 py-3' sm={6} md={3} >
        <RestCard/>
        </Col>
        <Col className='px-5 py-3' sm={6} md={3} >
        <RestCard/>
        </Col>
        </Row></div>
  )
}

export default Home