import React from 'react'
import { Col, Row } from 'react-bootstrap'
import ListGroup from 'react-bootstrap/ListGroup';
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import RestReview from '../components/RestReview';

function RestView() {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
  return (
    <div><Row>
        <Col md={4} sm={12}>
        <img style={{width:'100%',height:'400px'}}  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQziSw-LcuTUvKV9WK-cEkNg2e5dONXOUevPHKv4Cf-WWq2SxPz1ov-Um9C8IZkiZFRi0&usqp=CAU" alt="" />
        
        
        </Col>
        <Col md={8} sm={12}>
            <hr />
            <h3 className='text-center'>RESTAURANT <span className='text-warning'>DETAILS</span></h3>
            <hr />
        <ListGroup>
        <ListGroup.Item className='text-center p-3' style={{fontSize:'25px',fontWeight:'15px'}}>Katz's Delicatenessen</ListGroup.Item>    
      <ListGroup.Item>NeighbourHood:</ListGroup.Item>
      <ListGroup.Item>Cuisine_Type:</ListGroup.Item>
      <ListGroup.Item>Address:</ListGroup.Item>
      <ListGroup.Item><div className='d-flex justify-content-center'> 
        
        <button onClick={handleShow} className='btn btn-warning m-3'> Opearating Hours</button>
       
       <RestReview/>
       
       </div></ListGroup.Item>
      

    </ListGroup>
  
      
        
        </Col>
        
        
        </Row>
        <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title> Operating Hour</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <ListGroup>
        <ListGroup.Item>Monday :</ListGroup.Item>
        <ListGroup.Item>Tuesday :</ListGroup.Item>
        <ListGroup.Item>Wednesday :</ListGroup.Item>
        <ListGroup.Item>Thursday :</ListGroup.Item>
        <ListGroup.Item>Friday :</ListGroup.Item>
        <ListGroup.Item>Saturday :</ListGroup.Item>

        </ListGroup>
        </Modal.Body>
       
      </Modal></div>
  )
}

export default RestView