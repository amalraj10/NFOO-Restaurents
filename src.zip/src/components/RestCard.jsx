import React from 'react'
import { Card } from 'react-bootstrap'
import { Link } from 'react-router-dom'

function RestCard() {
  return (
    
    <div> <Link style={{textDecoration:'none'}} to={'/restaurentview'}><Card className='card shadow' style={{ width: '18rem' }}>
    <Card.Img variant="top" src="https://images.immediate.co.uk/production/volatile/sites/30/2015/02/Top-10-foods-to-try-in-Spain-1d2b4ef.jpg?quality=90&resize=556,505" />
    <Card.Body>
      <Card.Title ><center>Emily</center></Card.Title>
      <hr />
      
      <Card.Text className='d-flex justify-content-between'>
       <p> Manhattan </p>
       <p> cousin : Asian</p>
      </Card.Text>
      
      
       
      
    </Card.Body>
  </Card></Link></div>
  )
}

export default RestCard