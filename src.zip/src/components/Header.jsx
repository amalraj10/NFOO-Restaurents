import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

function Header() {
  return (
    <div>
         <Navbar className="bg-body-tertiary">
     
     <Navbar.Brand href={'./'}>
     <h4 className='ms-5' ><i class="fa-solid fa-bacon me-2"></i>NFOO</h4>
     </Navbar.Brand>
 
 </Navbar>
    </div>
  )
}

export default Header