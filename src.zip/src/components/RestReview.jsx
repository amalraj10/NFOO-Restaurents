import React from 'react'

function RestReview() {
  return (
    <div>
                <button className='btn btn-warning m-3'> Click Here To See Reviews</button>

    </div>
  )
}

export default RestReview